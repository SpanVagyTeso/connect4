#include "customdialog.h"
#include <QFile>
#include <QFileInfo>
#include <QTextStream>
#include <QString>
#include <iostream>

CustomDialog::CustomDialog(GameManager& _gm,QWidget* parent):gm(_gm),QDialog(parent){
    //std::cout<<" Constructor"<<std::endl;
    setFixedSize(300, 200);
    list = new QListWidget(this);
    list->setGeometry(0,0,100,100);
    for(int i=0;i<5;i++){
       // list->addItem("sav" + QString::number(i) + ".krisi");
        QString filename="sav" + QString::number(i) + ".krisi";
        //QFile file(filename);
        //file.open(QIODevice::ReadWrite);
        if (QFile::exists("sav" + QString::number(i) + ".krisi")){
            list->addItem(filename);
        }
    }
    btn = new QPushButton(this);
    btn->setText("");
    btn->setGeometry(120,35,60,30);
}
