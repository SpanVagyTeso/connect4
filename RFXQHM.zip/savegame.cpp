#include "savegame.h"
#include <QFile>
#include <QTextStream>

SaveGame::SaveGame(GameManager& _gm,QWidget* parent):CustomDialog(_gm,parent){
    btn->setText("Mentés");
    list->clear();
    for(int i=0;i<5;i++){
        QString a = QString("sav")+QString::number(i)+QString(".krisi");
        list->addItem(a);
    }
    connect(btn,SIGNAL(released()),this,SLOT(click()));
}

void SaveGame::click(){
    QString filename=list->selectedItems()[0]->text();
    QFile file( filename );
    if ( file.open(QIODevice::ReadWrite) )
    {
        QTextStream stream( &file );
        stream << gm.getCP()<<endl;
        stream << gm.getRow() << " "<<gm.getColumn()<<endl;
        for(int i=0;i<gm.getRow();i++){
            for(int j=0;j<gm.getColumn();j++){
                stream << gm.getField(j,i)<<" ";
            }
            stream<<endl;
        }
    }
    file.close();
    accept();
}
