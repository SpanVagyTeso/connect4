#ifndef SAVEGAME_H
#define SAVEGAME_H

#include "customdialog.h"
#include "gamemanager.h"
class SaveGame:public CustomDialog
{
    Q_OBJECT
public:
    SaveGame(GameManager& _gm,QWidget* parent);
private slots:
    void click();
};


#endif // SAVEGAME_H
