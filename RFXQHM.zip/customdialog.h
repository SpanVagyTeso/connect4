#ifndef CUSTOMDIALOG_H
#define CUSTOMDIALOG_H

#include <QDialog>
#include <QListWidget>
#include <QPushButton>

#include "gamemanager.h"

class CustomDialog:public QDialog
{

public:
    CustomDialog(GameManager& _gm,QWidget* parent);
protected:
    QListWidget* list;
    QPushButton* btn;
    GameManager& gm;
};

#endif // CUSTOMDIALOG_H
