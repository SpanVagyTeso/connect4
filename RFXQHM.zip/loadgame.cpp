#include "loadgame.h"
#include <QFile>
#include <QFileInfo>
#include <QTextStream>
#include <QString>

#include <iostream>


LoadGame::LoadGame(GameManager& _gm, QWidget* parent):CustomDialog(_gm,parent){

    btn->setText("Betölt");
    connect(btn,SIGNAL(released()),this,SLOT(click()));

}

void LoadGame::click(){
    if(list->currentItem()==nullptr)return;
    QFile file(list->currentItem()->text());
    //std::cout<<" 1"<<std::endl;
    file.open(QIODevice::ReadWrite);
    //std::cout<<" 2"<<std::endl;
    int currentplayer;
    //std::cout<<" 3"<<std::endl;
    int row,column;
    //std::cout<<" 4"<<std::endl;
    QTextStream stream(&file);
    //std::cout<<" 5"<<std::endl;
    QString line = stream.readLine();
    //std::cout<<" 6"<<std::endl;
    currentplayer=line.toInt();
    //std::cout<<" 7"<<std::endl;
    line=stream.readLine();
    //std::cout<<" 8"<<std::endl;
    row=line.split(" ")[0].toInt();
    //std::cout<<" 9"<<std::endl;
    column=line.split(" ")[1].toInt();
    //std::cout<<" 10"<<std::endl;
    gm.newGame(row,column);
    //std::cout<<" 11"<<std::endl;
    for(int i=0;i<row;i++){
        line=stream.readLine();
        for(int j=0;j<column;j++){
            gm.loadGame(j,i,line.split(" ")[j].toInt());
        }
    }
    gm.setCP(currentplayer);
    accept();
}
