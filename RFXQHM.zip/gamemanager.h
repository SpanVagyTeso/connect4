#ifndef GAMEMANAGER_H
#define GAMEMANAGER_H
#include <vector>
#include <QObject>

class GameManager:public QObject
{
    Q_OBJECT
private:
    struct Column{
        std::vector<int> column;
        unsigned int db;
        Column(){
            db=0;
        }
    };

    std::vector<Column> field;

    unsigned int columnN,rowN;
    unsigned int DB;
    int type;
    bool currentPlayer;
    void checkGame(int, int);
    void print();

public:
    GameManager();
    void place(int pos);
    void newGame(int type);
    void newGame(int,int);
    void loadGame(int column,int row,int player);
    void setCP(int player);
    int getField(int, int);
    int getColumn(){return columnN;}
    int getRow(){return rowN;}
    int getCP(){return currentPlayer+1;}
signals:
    void gameWon(int player);         //Win
    void gameOver();        //Draw
    void fieldChange(int x,int y,int player);
    void tableGraph(int,int);



};

#endif // GAMEMANAGER_H
