#ifndef LOADGAME_H
#define LOADGAME_H

#include "customdialog.h"
#include "gamemanager.h"


class LoadGame:public CustomDialog
{
    Q_OBJECT
public:
    LoadGame(GameManager& _gm,QWidget* parent);
private slots:
    void click();
};

#endif // LOADGAME_H
